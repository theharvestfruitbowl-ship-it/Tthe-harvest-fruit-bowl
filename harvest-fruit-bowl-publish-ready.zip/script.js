const menuToggle = document.getElementById('menuToggle');
const navigation = document.getElementById('navigation');

menuToggle.addEventListener('click', () => {
  const isOpen = navigation.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});

navigation.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    navigation.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation');
  });
});

const whatsappNumber = '919392151514';
document.querySelectorAll('.order-button').forEach((button) => {
  const item = button.dataset.item;
  const message = `Hello The Harvest Fruit Bowl, I am interested in: ${item}. Please share the details.`;
  button.href = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
  button.target = '_blank';
  button.rel = 'noopener';
});

document.getElementById('year').textContent = new Date().getFullYear();
